export const UrlEndPoint={
    PAGE_NO1:1
}

