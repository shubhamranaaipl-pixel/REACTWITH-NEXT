"use client";

import Image from "next/image";
import { ImageConstant } from "@/constant/imageconstant";
import style from "@/component/Header/header.module.scss";


export default function Header() {
  return (
    <header className={style.header_container}>
      <Image
        className={style.header_container_image}
        src={ImageConstant.LOGO_IMAGE}
        alt="LogoImage"
        width={60}
        height={60}
      />

      <div className={style.header_container_searchbar}>
        <input type="text" name="searchbar" placeholder=" Search Item..." className={style.header_container_searchbar_input}/>
        <button className={style.header_container_searchbar_button}>Search</button>
      </div>
    </header>
  );
}
