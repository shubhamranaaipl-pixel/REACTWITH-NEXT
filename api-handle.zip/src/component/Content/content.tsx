"use client";

import Image from "next/image";
import { ImageConstant } from "@/constant/imageconstant";
import style from "@/component/Content/content.module.scss";
import { useContent } from "./useContent";
import { ButtonConstant } from "@/constant/buttonconstant";
import { IResultData } from "@/modules/content/model/IResultData";
export default function Content() {
  const { getApiDetails, changeUiData } = useContent();

  return (
    <div className={style.main_container}>
      <>
        {getApiDetails?.results.map((resultDataItem: IResultData, index) => (
          <div key={index} className={style.main_container_cards}>
            <Image
              className={style.main_container_cards_image}
              src={ImageConstant.CONTENT_IMAGE}
              alt={resultDataItem.name}
              height={200}
              width={200}
            />
            <h2 className={style.main_container_cards_heading}>
              {resultDataItem.name}
            </h2>
            <p className={style.main_container_cards_paragrpah}>
              {resultDataItem.birth_year}
            </p>
          </div>
        ))}

        <div className={style.main_container_footer}>
          <button className={style.main_container_footer_button}>
            <Image
              src={ImageConstant.LEFT_ARROW}
              alt="left arrow"
              width={20}
              height={20}
            />
          </button>
          <button
            className={style.main_container_footer_button}
            onClick={() => changeUiData(ButtonConstant.PAGE_NO1)}
          >
            1
          </button>
          <button
            className={style.main_container_footer_button}
            onClick={() => changeUiData(ButtonConstant.PAGE_NO2)}
          >
            2
          </button>
          <button
            className={style.main_container_footer_button}
            onClick={() => changeUiData(ButtonConstant.PAGE_NO3)}
          >
            3
          </button>
          <button
            className={style.main_container_footer_button}
            onClick={() => changeUiData(ButtonConstant.PAGE_NO4)}
          >
            4
          </button>
          <button className={style.main_container_footer_button}>
            <Image
              src={ImageConstant.RIGHT_ARROW}
              alt="left arrow"
              width={20}
              height={20}
            />
          </button>
        </div>
      </>
    </div>
  );
}
