"use client";
import { config } from "@/config/confix";
import { useState, useEffect } from "react";
import { UrlEndPoint } from "@/constant/endpointconstant";
import { IGetDEtails } from "@/modules/content/model/IResultData";



export const useContent = () => {
  const [getApiDetails, setApiDetails] = useState<IGetDEtails>();
  useEffect(() => {
    const fetchPersonData = async () => {
      const res = await fetch(`${config.url}${UrlEndPoint.PAGE_NO1}`);
      const data = await res.json();
      setApiDetails(data);
    };

    fetchPersonData();
  }, []);

  const changeUiData = async (page: number) => {
    const res = await fetch(`${config.url}${page}`);
    const data = await res.json();
    setApiDetails(data);
  };

  return {
     getApiDetails,
    changeUiData,
  };
};
