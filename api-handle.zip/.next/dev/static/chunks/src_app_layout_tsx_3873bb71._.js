(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_d96d33e1._.js",
  "static/chunks/src_bf9746f9._.js",
  "static/chunks/src_8b453d6d._.css"
],
    source: "dynamic"
});
