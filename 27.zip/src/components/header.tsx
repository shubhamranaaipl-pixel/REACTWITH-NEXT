"use client"
import {IMAGE_URL} from "@/Api/product";
import "./header.scss"



 


export default function Header(){

  



   


    return(
        <header className="header_container">
          
        <img src={IMAGE_URL} alt="Website logo" className="header_container_logo" />
          <h1>Shooping App</h1>
        <ul className="header_container_lists">
            <li>Home</li>
            <li>Contact</li>
          
            <li>WishLists:{value.whishlist.length}</li>
           
             <li>Cart:{value.cart.length}</li>
        </ul>
        </header>
    )
}