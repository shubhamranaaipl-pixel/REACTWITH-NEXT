"use client";

import { createContext ,useEffect,useState,useReducer} from "react";
import { ICounterState } from "./IGlobalInterface";
import {LOCAL_CART,LOCAL_WHISHLIST} from "../constant/storagename"
import IProducts from "@/types/IProducts";
import Wishlist from "@/app/wishlist/page";



export const GlobalContext =createContext<ICounterState|null>(null);

const intialState={
  product:[],
  cart:[],
  whishlist:[],
}

export const GlobalProvider =({children}:{children:React.ReactNode})=>{

  const reducerfn=(state,action)=>{
    console.log("action",action)
      switch (action.type){
        case "FetchSucces":
          return{
            ...state,
            product:action.payload,
          }

      case "CartData":
        return{
          ...state,
          cart:action.payload,
        }
        case "whishlist":
          return{
            ...state,
            whishlist:action.payload,
          }
         
        case "FetchWhishlist":
            return{
              ...state,
              whishlist:action.payload,
            }

        case "FetchCart":
          return {
            ...state,
            cart:action.payload,
          }    
        case "Like_item":
          
          const LikeItem=state.whishlist.some((t:IProducts)=>t.id === action.payload.id);
          console.log(LikeItem)
          if(!LikeItem){
            console.log(" Like Button Clicked ")
          state.whishlist.push({...action.payload,isLiked: true});
       
        }
         

          localStorage.setItem(LOCAL_WHISHLIST,JSON.stringify(state.whishlist));
          // console.log('state',state)
         

          return state;
        

         case "AddTocart":
          const cartItem=state.cart.some((t:IProducts)=>t.id === action.payload.id);
          if(!cartItem){
            state.cart.push(action.payload);
          }
          else{
            console.log("Clicked Again")
          }

          localStorage.setItem(LOCAL_CART,JSON.stringify(state.cart));
          return state;
      }
  }  



  const [state,dispatch]=useReducer(reducerfn,intialState);
    
    
     useEffect(()=>{
     const whishlistdata=localStorage.getItem(LOCAL_WHISHLIST);
     const localwhishlist=whishlistdata? JSON.parse(whishlistdata):[];
     dispatch({type:"FetchWhishlist", payload:localwhishlist})

     const cartdata=localStorage.getItem(LOCAL_CART);
     const localcart=cartdata? JSON.parse(cartdata):[];
     dispatch({type:"FetchCart" ,payload:localcart})
    
    },[])
   
    return(
    <GlobalContext.Provider value={{state,dispatch}}>
       {children}
    </GlobalContext.Provider>
    )
}



