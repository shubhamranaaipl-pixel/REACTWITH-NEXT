interface IProducts{
  id:number;
  title:string;
  price:number;
  description:string;
  image:string;
  category:string;
  isClicked:boolean;
  count:number;
  isLiked:boolean;
}
export default IProducts;