"use client";

import "./LikeItem.scss"
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
import IProducts from "@/types/IProducts";




export default function LikeItem(){

    const globaldata=useContext(GlobalContext);

 
    if(!globaldata){
        throw new Error("GLobal Data are not found")
    }
    const {state,dispatch}=globaldata
    return (
        <>
        <h1 className="container_heading">Global Data Page</h1>
     <main className="card_container">  
      {state.whishlist?.map((item:IProducts,index)=>(
        <div key={index} className="card_container_cards">
            <img src={item.image} alt={item.title } className="card_container_cards_image"/>
            <h4 className="card_container_cards_title">Title:{item.title}</h4>
            <button className="card_container_cards_button" onClick={()=>dispatch({type:"Delete_item",payload:item})}>Remove</button>
        </div>
      ))} 
     
     </main>
     </>
    )
}