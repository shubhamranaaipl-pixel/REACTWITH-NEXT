"use client"

import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
import IProducts from "@/types/IProducts";
import "../../style/cartpage.scss"

export default function StateCart(){
const cartData=useContext(GlobalContext);

if(!cartData){
    throw new Error("Cart Data are not found");
}
const {state,dispatch}=cartData;

    return(
      <>
        <h1 className="heading">Cart Page </h1>
        <main className="cart_container"> 
          
         {state.cart.map((item:IProducts,index)=>
         <div key={index} className="cart_container_items">   
            <img src={item.image} alt={item.title}  className="cart_container_items_image"/>
            
             <h3 className="cart_container_items_title">Title: {item.title}</h3>  
              <button  onClick={()=>dispatch({type:"Decrement_count",payload:item})} className="cart_container_items_decrement">-</button> 
              <h3> {item.count}</h3>
              <button onClick={()=>dispatch({type:"Increment_count",payload:item})} className="cart_container_items_increment">+</button>
             
            <button onClick={()=>dispatch({type:"Delete_CartItem" ,payload:item})} className="cart_container_items_button">Delete</button>
         </div>
        )}
        </main>
         </>
    )
}