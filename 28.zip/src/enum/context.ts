

export enum LocalData{
     Cartdata="FetchCart",
     WhishlistData="FetchWhishlist"
}

export enum Api{
    ApiData="FetchSucces"
}

export enum SwitchCase{
 ApiSucess="FetchSucces",
 CartData="CartData",
 whishlist="whishlist",
 WhishlistData="FetchWhishlist",
 FetchCart="FetchCart",
 LikeButton="Like_item",
 DelteButton="Delete_item",
 AddToCartButton="AddTocart",
 DeleteCart="Delete_CartItem",
 IncrementButton="Increment_count",
 DecrementCount="Decrement_count"

    
}