"use client";

import { createContext, useEffect, useReducer } from "react";
import { ICounterState } from "./IGlobalInterface";
import { LOCAL_CART, LOCAL_WHISHLIST } from "../constant/storagename";
import IProducts from "@/types/IProducts";
import { API_URL } from "@/Api/product";
import { SwitchCase,LocalData,Api } from "@/enum/context";


export const GlobalContext = createContext<ICounterState | null>(null);

const intialState = {
  product: [],
  cart: [],
  whishlist: [],
};

export const GlobalProvider = ({ children }: { children: React.ReactNode }) => {
  const reducerfn = (state, action) => {
    console.log("action", action);

    switch (action.type) {
      case SwitchCase.ApiSucess:
        return {
          ...state,
          product: action.payload,
        };

      case SwitchCase.CartData:
        return {
          ...state,
          cart: action.payload,
        };

      case SwitchCase.whishlist:
        return {
          ...state,
          whishlist: action.payload,
        };

      case SwitchCase.WhishlistData:
        return {
          ...state,
          whishlist: action.payload,
        };

      case SwitchCase.FetchCart:
        return {
          ...state,
          cart: action.payload,
        };

      case SwitchCase.LikeButton:
        const LikeItem = state.whishlist.some(
          (t: IProducts) => t.id === action.payload.id
        );
        console.log(LikeItem);

        const newList = LikeItem
          ? state.whishlist.filter((t: IProducts) => t.id !== action.payload.id)
          : [...state.whishlist, { ...action.payload, isLiked: true }];
        localStorage.setItem(LOCAL_WHISHLIST, JSON.stringify(newList));
        return {
          ...state,
          whishlist: newList,
        };

      case SwitchCase.DelteButton:
        const filterdata = state.whishlist.filter(
          (t: IProducts) => t.id !== action.payload.id
        );
    
        localStorage.setItem(LOCAL_WHISHLIST, JSON.stringify(filterdata));
        return {
          ...state,
          whishlist: filterdata,
        };

      case SwitchCase.AddToCartButton:
        const cartItem = state.cart.some(
          (t: IProducts) => t.id === action.payload.id
        );

        const newCart = cartItem
          ? state.cart.map((option: IProducts) =>
              option.id === action.payload.id
                ? { ...option, count: option.count + 1 }
                : option
            )
          : [...state.cart, { ...action.payload, count: 1 }];

        localStorage.setItem(LOCAL_CART, JSON.stringify(newCart));
        return {
          ...state,
          cart: newCart,
        };

      case SwitchCase.DeleteCart:
        const filtercartdata = state.cart.filter(
          (t: IProducts) => t.id !== action.payload.id
        );
        localStorage.setItem(LOCAL_CART, JSON.stringify(filtercartdata));
        return {
          ...state,
          cart: filtercartdata,
        };

      case SwitchCase.IncrementButton:
        const cartdata = state.cart.map((item: IProducts) =>
          item.id === action.payload.id ? { ...item, count: item.count + 1 } : item
        );

        localStorage.setItem(LOCAL_CART, JSON.stringify(cartdata));

        return {
          ...state,
          cart: cartdata,
        };


      case SwitchCase.DecrementCount:
        const decrementCartData = [...state.cart];
        const findData = decrementCartData.findIndex(
          (t: IProducts) => t.id === action.payload.id
        );
        if (findData !== -1) {
          if (decrementCartData[findData].count > 1) {
            const value = decrementCartData[findData].count - 1;
            decrementCartData[findData] = {
              ...decrementCartData[findData],
              count: value,
            };
            localStorage.setItem(LOCAL_CART, JSON.stringify(decrementCartData));
            return {
              ...state,
              cart: decrementCartData,
            };
          } else {
            const decrementdata = decrementCartData.filter(
              (t: IProducts) => t.id !== action.payload.id
            );
            localStorage.setItem(LOCAL_CART, JSON.stringify(decrementdata));
            return {
              ...state,
              cart: decrementdata,
            };
          }
        }
       
      

    }
  };

  const [state, dispatch] = useReducer(reducerfn, intialState);

  useEffect(() => {
    const cartItem = localStorage.getItem(LOCAL_CART);
    const localcartdata = cartItem ? JSON.parse(cartItem) : [];
    dispatch({ type:LocalData.Cartdata, payload: localcartdata });

    const whishlist = localStorage.getItem(LOCAL_WHISHLIST);
    const localwhishlist = whishlist ? JSON.parse(whishlist) : [];
    dispatch({ type: LocalData.WhishlistData, payload: localwhishlist });

    async function FetchData() {
      const res = await fetch(API_URL);
      const data = await res.json();
      dispatch({ type: Api.ApiData, payload: data });
    }
    FetchData();
  }, []);

  return (
    <GlobalContext.Provider value={{ state, dispatch }}>
      {children}
    </GlobalContext.Provider>
  );
};
