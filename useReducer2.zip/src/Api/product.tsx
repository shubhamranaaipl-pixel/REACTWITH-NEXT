export const API_URL="https://fakestoreapi.com/products";
export const IMAGE_URL="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaUaCmDwRWq1xNfGksNkoiLzEl-z1Ec0kZYQ&s"
