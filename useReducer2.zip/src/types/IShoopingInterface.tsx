 export  default interface Istate{
    IntialCount:number;
}

