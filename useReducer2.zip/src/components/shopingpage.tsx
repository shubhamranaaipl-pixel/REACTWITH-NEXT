"use client";

import {  useEffect, useReducer, useState } from "react";
import IProducts from "@/types/IProducts";
import { API_URL } from "@/Api/product";
import "./shoping.scss";
import Header from "./header";
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
import { LOCAL_CART, LOCAL_PRODUCT } from "../constant/storagename";



const intialState = {
  intialCount: 0,
  product: [],
  cart:[],
};



export default function ShoppingPage() {

  const ClickCounter = useContext(GlobalContext);

  const countData = ClickCounter?.count;
const [state, dispatch] = useReducer(reducer, intialState);

  const [cart, setCart] = useState<IProducts[]>([]);

  function reducer(state ,action) {
    switch (action.type) {

      case "FetchSucces":
        
        return{
           intialCount:0,
           product:action.payload,
            cart:state.cart
          }
        

      case "CartData":
         return{
           intialCount:0,
           product:state.product,
           cart:action.payload
         }
         
      case "AddToCart":

         
        const cart=state?.cart?.cartdata;

        const find = cart.some((item:IProducts) => item.id === action.payload.data.id);
   
        let updateCart;
        if (!find) {
          console.log("Render the IF Block");

          updateCart = [...cart, { ...action.payload.data, count: 1 }];
          localStorage.setItem(LOCAL_CART, JSON.stringify(updateCart));
          // setCart(updateCart); 
          dispatch(({type:"CartData",payload:{updateCart}}))
        } else {
 
          const data = state?.cart?.cartdata.findIndex((t:IProducts) => t.id == action.payload.data.id);
        console.log("THe index Data come from the cart2 -45", cart[data].count);
          if (data != -1) {
            console.log("THe index Data come from the cart2 -47", cart[data].count);
            cart[data] = { ...cart[data], count: (cart[data].count += 1) };
             console.log("THe index Data come from the cart2 -51", cart[data].count);
            localStorage.setItem(LOCAL_CART, JSON.stringify(cart));
            // setCart(cart);
            dispatch(({type:"CartData",payload:{cart}}))
            
          }
        }

        return {
         
        };
      case "Like_item":

        const findProduct=ClickCounter?.count.some(item=>item.id === action.payload.data.id);
        // console.log(findProduct);
        if(!findProduct){
          ClickCounter?.setcount([...(ClickCounter?.count),{
            image:action.payload.data.image,
            id:action.payload.data.id,
            title:action.payload.data.title,
          }])
        }
        else{
          const filterdata=ClickCounter?.count.filter(item=>item.id !== action.payload.data.id);
          // console.log(filterdata)
          localStorage.setItem(LOCAL_PRODUCT,JSON.stringify(filterdata));
          ClickCounter?.setcount(filterdata??[]);
        }
        return{}
    }
  }
  



  useEffect(() => {
    const cartprev = localStorage.getItem(LOCAL_CART);
    const cartdata = cartprev ? JSON.parse(cartprev) : [];
    // console.log(cartdata)
    // setCart(cartdata);
     dispatch(({type:"CartData",payload:{cartdata}}))
  
  }, []);
  useEffect(() => {
    async function FetchData() {
      const res = await fetch(API_URL);
      const data = await res.json();
      dispatch(({type:"FetchSucces", payload:{data}}))
    }
    FetchData();
  }, []);

  
  return (
    <>
      <Header Cart={cart} />
      {console.log("The state Product data are ",state)};
      <main className="main_conatainer">
        {state?.product.data?.map((data: IProducts) => {
          const cartItem = cart.find((item) => item.id === data.id);
          return (
            <div key={data.id} className="container">
              <img
                src={data.image}
                alt={data.title}
                className="container_image"
              />
              <h1 className="container_category">Category:{data.category}</h1>
              <p className="container_title">Title:{data.title}</p>
              <h1 className="container_price">Price:${data.price}</h1>
              <p className="container_description">
                Description:{data.description}
              </p>


              <button
              className={
                  countData?.some((item) => item.id === data.id)
                    ? "container_button2"
                    : "container_button"
                }
                onClick={() =>
                  dispatch({ type: "Like_item", payload: { data } })
                }
              >
                Like
              </button>



              <button
                className="container_addButton"
                onClick={() =>
                  dispatch({ type: "AddToCart", payload: { data } })
                }
              >
                AddToCArt{" "}
              </button>
              <p>Count:{cartItem?.count ??  0}</p>
            </div>
          );
        })}
      </main>
    </>
  );
}
