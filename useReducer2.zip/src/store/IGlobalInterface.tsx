 interface IArrayData{
  id:number;
  title:string;
  image:string;
  
 }
export interface ICounterState{
   count:IArrayData[];
   setcount:(newData:IArrayData[])=>void;
}