"use client";

import { createContext ,useEffect,useState} from "react";
import { ICounterState } from "./IGlobalInterface";
import {LOCAL_PRODUCT} from "../constant/storagename"

export const GlobalContext =createContext<ICounterState|null>(null);


export const GlobalProvider =({children}:{children:React.ReactNode})=>{

    const [count,setcount]=useState([]);
    
     useEffect(()=>{
      const data =localStorage.getItem(LOCAL_PRODUCT);
      // console.log("Re -render ")
      const localdata=data? JSON.parse(data):[];
      setcount(localdata)
    },[])

    useEffect(()=>{
      localStorage.setItem(LOCAL_PRODUCT,JSON.stringify(count));
      // console.log("Re -render2")
    },[count])

    return(
    <GlobalContext.Provider value={{count,setcount}}>
       {children}
    </GlobalContext.Provider>
    )
}



