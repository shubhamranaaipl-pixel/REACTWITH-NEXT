"use client";
import Header from "@/component/Header/header";
import Image from "next/image";
import styles from "./content.module.scss";
import { useContent } from "./useContent";
import Footer from "../Footer/footer";
import {useRouter} from "next/navigation"


export default function Content() {
  const { uidata } = useContent();
  const router=useRouter();
  
 

  const Getdetails=(id:number)=>{
    router.push(`/details/${id}`);
  
  }
  return (
    <>
      <Header />

      <main className={styles.main_container}>
        {uidata.map((item, index) => (
          <div key={index} className={styles.main_container_card}>
            <Image
              src={item.image}
              alt={item.title}
              width={200}
              height={200}
              className={styles.main_container_card_image}
            />
            <h6 className={styles.main_container_title}>Title:{item.title}</h6>
            <button className={styles.main_container_card_button} onClick={()=>Getdetails(item.id)}> View Details</button>
          </div>
        ))}
      </main>
      <Footer />
    </>
  );
}
