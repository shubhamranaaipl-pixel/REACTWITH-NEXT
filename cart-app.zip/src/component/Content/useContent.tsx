"use client";
import { Urlconfig } from "@/config/urlconfig";
import { useEffect, useState } from "react";
export const useContent = () => {
  const [uidata, setData] = useState([]);

  useEffect(() => {
    async function FetchData() {
      const res = await fetch(Urlconfig.fetchUrl || "");
      const data = await res.json();
      localStorage.setItem("cartItems",JSON.stringify(data))
      setData(data);
    }
    FetchData();
  }, []);   

  useEffect(() => {
    const fetchData = () => {
      const data = localStorage.getItem("cartItems");
      const localdata = data ? JSON.parse(data) : [];
      setData(localdata);
    };
    fetchData();
  },[]);

  return {
    uidata,
  };
};
