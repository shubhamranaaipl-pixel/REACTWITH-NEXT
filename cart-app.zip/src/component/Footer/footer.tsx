"use client";
import styles from "./footer.module.scss"

export default function Footer() {
  return (
    <footer className={styles.footer_container}>
      <h2 className={styles.footer_container_heading}>Shopping Website</h2>
      <p className={styles.footer_container_paragraph}>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint est,
        facilis commodi totam, nemo quae accusantium similique vero quia dolores
        nesciunt consequatur rem sequi? Explicabo vitae cupiditate tempore!
        Repellendus ipsa reiciendis ex eligendi labore!
      </p>
    </footer>
  );
}
