"use Client";
import Image from "next/image";
import Link from "next/link";
import styles from"./header.module.scss";
import { ImageConstant } from "@/constant/imageconstant";
export default function Header(){


    
    return(
       <header className={styles.header_container}>
       <Image 
       className={styles.header_container_image}
       src={ImageConstant.logo}
       alt="NotFound"
       width={60}
       height={60}
       />

      <h2 className={styles.header_container_heading}>Shopping WebSite</h2>
      <ul className={styles.header_container_lists}>
        <li ><Link className={styles.header_container_lists_li}  href="/">Home</Link></li>
         <li ><Link className={styles.header_container_lists_li}  href="/contact">Contact</Link></li>
         <li ><Link  className={styles.header_container_lists_li}   href="/cart">Cart</Link></li>
      </ul>

       </header>
    )
}