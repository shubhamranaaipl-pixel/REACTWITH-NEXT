export const ImageConstant={
    logo:"/images/logo.png"
}