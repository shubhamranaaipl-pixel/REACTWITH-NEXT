export const Urlconfig={
    fetchUrl:process.env.NEXT_PUBLIC_FETCH_URL||"",
}