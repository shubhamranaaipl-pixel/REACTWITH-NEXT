"use client";


import { createContext, useEffect } from "react";
import { useState } from "react";

export const CartContext = createContext(undefined);

export const CartProvider = ({ children }: { children: React.ReactNode }) => {
  const [data, setData] = useState([]);
  const [cartdata, setcartData] = useState([]);

  const AddToCart = (id: number) => {
    const isItemExists = cartdata.some((item) => item.id === id);
    if(!isItemExists){
     const itemToAdd=data.find((item)=>item.id ===id);
     if(itemToAdd){
       const updatedCartData=[...cartdata,{itemToAdd,count:1}];
       localStorage.setItem("cartData",JSON.stringify(updatedCartData));
       setcartData(updatedCartData);
     }    
    }
 
     
  };

  useEffect(() => {
    const fetchData = () => {
      const data = localStorage.getItem("cartItems");
      const localdata = data ? JSON.parse(data) : [];
      setData(localdata);
    };
    fetchData();
  }, []);

  useEffect(() => {
    const FetchData = () => {
      const cartdata = localStorage.getItem("cartData");
      const localcartdata = cartdata ? JSON.parse(cartdata) : [];
      setcartData(localcartdata);
    };
    FetchData();
  }, []);
  return (
    <CartContext.Provider value={{ AddToCart }}>
      {children}
    </CartContext.Provider>
  );
};
