"use client";
import { useParams } from "next/navigation";
import { useContent } from "@/component/Content/useContent";
import Image from "next/image";
import Header from "@/component/Header/header";
import Footer from "@/component/Footer/footer";
import styles from "./details.module.scss";
import { useContext } from "react";
import { CartContext } from "@/context/cartContext";
export default function DetailPage() {

  const {AddToCart}=useContext(CartContext);
  const { uidata } = useContent();
  const param = useParams();
  const { id } = param;

  const details = uidata.find((item) => Number(item.id) === Number(id));
  
 

  return (
    <>
      <Header />
       <h1 className={styles.heading}>Details Page</h1>
      <div className={styles.details_container}>
     
      {details?.image ? (
        <Image  className={styles.details_container_image}  src={details?.image} alt="Product" width={200} height={200} />
      ) : (
        <p>Loading image...</p>
      )}
      <aside className={styles.details_container_aside}>
      <h1 className={styles.details_container_aside_title}>Title:{details?.title || ""}</h1>
      <h2 className={styles.details_container_aside_price}>Price:${details?.price || ""}</h2>
      <h5 className={styles.details_container_aside_category}>Category:{details?.category}</h5>
      <p className={styles.details_container_asider_description}>Description:{details?.description || ""}</p>
      <button className={styles.details_container_aside_button} onClick={()=>AddToCart(details?.id)}>Add To Cart</button>
      </aside>
       </div>
      <Footer />
    </>
  );
}
