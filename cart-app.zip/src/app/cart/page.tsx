"use client";
export default function CartPage(){
    return (
        <>
        <h1>Hello From the Cart Page</h1>
        </>
    )
}