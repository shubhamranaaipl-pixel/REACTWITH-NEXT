"use Client";

import Footer from "@/component/Footer/footer";
import Header from "@/component/Header/header";
import styles from "./contact.module.scss";

export default function ContactPage() {
  return (
    <>
        <Header/>
     <main className={styles.contact_container}>

      <h1 className={styles.contact_container_heading}>Contact Page </h1>
      <p className={styles.contact_container_paragraph}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam tempora
        dolorum corporis quasi optio, nemo nihil consequatur fugiat repellendus
        officia, quis tenetur id recusandae dignissimos ullam fugit minus et?
        Repellat, quos sed inventore magni beatae sint, sit reiciendis adipisci
        suscipit ratione cupiditate molestias eligendi delectus? Voluptatibus
        velit exercitationem architecto. Sit quo sint repudiandae dolorum
        veritatis, fugiat tempora dolor dolores dicta! Earum voluptate, dolore
        eligendi consectetur tempora at. Alias aspernatur recusandae quibusdam
        quas doloremque commodi culpa soluta temporibus corporis ullam ab
        repudiandae quis, magni deserunt nam tempore error. Perferendis, quis.
        Optio, minima! Tempore iste maiores laudantium exercitationem in
        repellat ea animi.
      </p> 
 
    </main>
    <Footer/>
    </>
   
  );
}
