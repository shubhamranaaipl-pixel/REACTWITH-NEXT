export const LOCAL_CART="cart";
export const LOCAL_PRODUCT="products"