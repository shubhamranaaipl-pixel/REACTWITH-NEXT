"use client"
import {IMAGE_URL} from "@/Api/product";
import "./header.scss"
import { useEffect, useState } from "react";
import IProducts from "@/types/IProducts";
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
import {LOCAL_PRODUCT} from "../constant/storagename"
interface HeaderProps{
    Cart?:IProducts[];
}
 
export default function Header(Cart:HeaderProps){
  //  console.log(Cart)
  const WhishlistCounter=useContext(GlobalContext);
//   console.log("The  Whishlist Items",WhishlistCounter?.count);
   
    const [items,setItem]=useState<IProducts[]>([]);


    // useEffect(()=>{
    //    const data =localStorage.getItem(LOCAL_PRODUCT);
    //    const localdata=data? JSON.parse(data):[];
    //    setItem(localdata) 
    // },[])

    return(
        <header className="header_container">
          
        <img src={IMAGE_URL} alt="Website logo" className="header_container_logo" />
          <h1>Shooping App</h1>
        <ul className="header_container_lists">
            <li>Home</li>
            <li>Contact</li>
          
            <li>WishLists:{WhishlistCounter?.count.length}</li>
           
             <li>Cart:{Cart?.Cart?.length}</li>
        </ul>
        </header>
    )
}