"use client";

import {  useEffect, useReducer, useState } from "react";
import IProducts from "@/types/IProducts";
import { API_URL } from "@/Api/product";
import "./shoping.scss";
import Header from "./header";
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
import { LOCAL_CART, LOCAL_PRODUCT } from "../constant/storagename";


const intialState = {
  intialCount: 0,
};



export default function ShoppingPage() {

  const ClickCounter = useContext(GlobalContext);

  const countData = ClickCounter?.count;


  const [product, setProduct] = useState<IProducts[]>([]);

  const [cart, setCart] = useState<IProducts[]>([]);

  function reducer(state,action) {
    switch (action.type) {
      case "AddToCart":
        //  console.log("Run inside the useReducer");
        //  console.log(action.payload.data)
        //  console.log(cart);
        const find = cart.some((item) => item.id === action.payload.data.id);
        let updateCart;
        if (!find) {
          updateCart = [...cart, { ...action.payload.data, count: 1 }];
          localStorage.setItem(LOCAL_CART, JSON.stringify(updateCart));
          setCart(updateCart);
        } else {
          const data = cart.findIndex((t) => t.id == action.payload.data.id);
       
          if (data != -1) {
            // console.log("THe index Data come from the cart2", cart[data].count);
            cart[data] = { ...cart[data], count: (cart[data].count += 1) };
            localStorage.setItem(LOCAL_CART, JSON.stringify(cart));
            setCart(cart);
          }
        }
        return {};
      case "Like_item":
        // console.log("Like is Clicked ");
        // console.log(action.payload.data);
        const findProduct=ClickCounter?.count.some(item=>item.id === action.payload.data.id);
        console.log(findProduct);
        if(!findProduct){
          ClickCounter?.setcount([...(ClickCounter?.count),{
            image:action.payload.data.image,
            id:action.payload.data.id,
            title:action.payload.data.title,
          }])
        }
        else{
          const filterdata=ClickCounter?.count.filter(item=>item.id !== action.payload.data.id);
          // console.log(filterdata)
          localStorage.setItem(LOCAL_PRODUCT,JSON.stringify(filterdata));
          ClickCounter?.setcount(filterdata??[]);
        }
        return{}
    }
  }
  const [state, dispatch] = useReducer(reducer, intialState);



  useEffect(() => {
    const cartprev = localStorage.getItem(LOCAL_CART);
    const cartdata = cartprev ? JSON.parse(cartprev) : [];
    setCart(cartdata);
  }, []);
  useEffect(() => {
    async function FetchData() {
      const res = await fetch(API_URL);
      const data = await res.json();
      setProduct(data);
    }
    FetchData();
  }, []);

  // const AddtoCart = (data: IProducts) => {

  //   const dataId = cart.some((option) => option.id === data.id);
  //   let Updatecart;

  //   if (!dataId) {
  //     Updatecart = [...cart, { ...data, count: 1 }];

  //     localStorage.setItem(LOCAL_CART, JSON.stringify(Updatecart));
  //     setCart(Updatecart);
  //   } else {
  //     const findindex = cart.findIndex((option) => option.id == data.id);
  //     if (findindex != -1) {
  //       const newCart = [...cart];
  //       newCart[findindex] = {
  //         ...newCart[findindex],
  //         count: (newCart[findindex].count += 1),
  //       };
  //       localStorage.setItem(LOCAL_CART, JSON.stringify(newCart));
  //       setCart(newCart);
  //     }
  //   }
  // };

  // const LikeItem = (data: IProducts) => {
  //   const isId = countData?.some((item) => item.id === data.id);
  //   // console.log(isId)
  //   if (!isId) {
  //     ClickCounter?.setcount([
  //       ...(countData ?? []),
  //       { image: data.image, id: data.id, title: data.title },
  //     ]);
  //   } else {
  //     const filterdata = countData?.filter((item) => item.id !== data.id);
  //     // console.log(filterdata)
  //     localStorage.setItem(LOCAL_PRODUCT, JSON.stringify(filterdata));
  //     ClickCounter?.setcount(filterdata ?? []);
  //   }
  // };
  return (
    <>
      <Header Cart={cart} />
   
      <main className="main_conatainer">
        {product.map((data) => {
          const cartItem = cart.find((item) => item.id === data.id);
          return (
            <div key={data.id} className="container">
              <img
                src={data.image}
                alt={data.title}
                className="container_image"
              />

              <h1 className="container_category">Category:{data.category}</h1>
              <p className="container_title">Title:{data.title}</p>
              <h1 className="container_price">Price:${data.price}</h1>
              <p className="container_description">
                Description:{data.description}
              </p>

              {/* <button
                className={
                  countData?.some((item) => item.id === data.id)
                    ? "container_button2"
                    : "container_button"
                }
                onClick={() => LikeItem(data)}
              >
                Like
              </button> */}

              <button
              className={
                  countData?.some((item) => item.id === data.id)
                    ? "container_button2"
                    : "container_button"
                }
                onClick={() =>
                  dispatch({ type: "Like_item", payload: { data } })
                }
              >
                Like
              </button>

              {/* <button
                className="container_addButton"
                onClick={() => AddtoCart(data)}
              >
                Add To Cart
              </button> */}

              <button
                className="container_addButton"
                onClick={() =>
                  dispatch({ type: "AddToCart", payload: { data } })
                }
              >
                AddToCArt{" "}
              </button>
              <p>Count:{cartItem?.count ??  0}</p>
            </div>
          );
        })}
      </main>
    </>
  );
}
