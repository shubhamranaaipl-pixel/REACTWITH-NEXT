"use client"
import { useEffect, useState } from "react";
import IProducts from "@/types/IProducts";
import "../../style/whishlistpage.scss";
import { LOCAL_PRODUCT } from "@/constant/storagename";
export default function Wishlist(){

   
    const [item, setItem] = useState<IProducts[]>([]);
    useEffect(() => {
        const data = localStorage.getItem(LOCAL_PRODUCT);
        const localdata = data ? JSON.parse(data) : [];
        setItem(localdata);      
    }, []);
  const DeleteButton=(id:number)=>{
   const data=item.filter(t=>t.id !== id);
   localStorage.setItem(LOCAL_PRODUCT,JSON.stringify(data));
   setItem(data);
  }
    return(
        <main className="wishlist_container">
            <h1 className="wishlist_container_heading" >Wish List</h1>
        {item.map((items,index)=>(
            <div key={index} className="wishlist_container_cards">
                <img src={items.image} alt={items.title} className="wishlist_container_cards_image"/>
                <h3 className="wishlist_container_cards_title">Title:{items.title}</h3>
                <button  className="wishlist_container_cards_button" onClick={()=>DeleteButton(items.id)}>Remove</button>
            </div>
        )
        )}
        </main>
    )
}