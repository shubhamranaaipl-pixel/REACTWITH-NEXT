"use client";

import { createContext ,useEffect,useState} from "react";

 export interface ICounterState{
   count: string[];

};

export const GlobalContext =createContext<ICounterState|null>(null);


export const GlobalProvider =({children}:{children:React.ReactNode})=>{
    const [count,setcount]=useState([]); 
    return(
    <GlobalContext.Provider value={{count,setcount}}>
       {children}
    </GlobalContext.Provider>
    )
}



