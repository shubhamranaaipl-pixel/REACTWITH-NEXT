"use client"

import IProducts from "@/types/IProducts"
import { useEffect, useState } from "react";
import "../../style/cartpage.scss";


export default function Cart(){
   const [cartItem,setcartItem]=useState<IProducts[]>([]);

   useEffect(()=>{
    const data=localStorage.getItem("cart");
    const local=data?JSON.parse(data):[];
    setcartItem(local);
   },[]);

  const DeleteItem=(id:number)=>{
    const updateddata=cartItem.filter(item=>item.id !== id);
    localStorage.setItem("cart",JSON.stringify(updateddata));
    setcartItem(updateddata)
  }
     
  const IncrementCount=(id:number)=>{
 const newCartItems = [...cartItem];
    const matchId=newCartItems.findIndex(data=>data.id === id);
    const value=newCartItems[matchId].count+=1;
    newCartItems[matchId]={...newCartItems[matchId],count:value};
    localStorage.setItem("cart",JSON.stringify(newCartItems));
    setcartItem(newCartItems);
  }
  const DecrementCount=(id:number)=>{
    const newCartItems = [...cartItem];
    const matchId=newCartItems.findIndex(data=>data.id === id);
    if(newCartItems[matchId].count>1){
      const value=newCartItems[matchId].count-=1;
      newCartItems[matchId]={...newCartItems[matchId],count:value};
      localStorage.setItem("cart",JSON.stringify(newCartItems));
      setcartItem(newCartItems)
    }
    else{
      const filterdata=newCartItems .filter(item=>item.id !== id);
      localStorage.setItem("cart",JSON.stringify(filterdata));
      setcartItem(filterdata)
    }
  }
    return(
      <>
        <h1 className="heading">Cart Page </h1>
        <main className="cart_container"> 
          
         {cartItem.map((item,index)=>
         <div key={index} className="cart_container_items">   
            <img src={item.image} alt={item.title}  className="cart_container_items_image"/>
            
             <h3 className="cart_container_items_title">Title: {item.title}</h3>  
              <button onClick={()=>DecrementCount(item.id)} className="cart_container_items_decrement">-</button> 
              <h3> {item.count}</h3>
              <button onClick={()=>IncrementCount(item.id)} className="cart_container_items_increment">+</button>
             
            <button onClick={()=>DeleteItem(item.id)} className="cart_container_items_button">Delete</button>
         </div>
        )}
        </main>
         </>
    )
}