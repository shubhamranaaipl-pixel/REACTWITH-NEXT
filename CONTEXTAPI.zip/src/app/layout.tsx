
import { GlobalProvider } from "@/store/Globalcontext";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <GlobalProvider>
        {children}
        </GlobalProvider>
      </body>
    </html>
  );
}
